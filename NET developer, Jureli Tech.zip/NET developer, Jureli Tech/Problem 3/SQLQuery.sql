CREATE DATABASE Students;
USE Students;

CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),  
    StudentName NVARCHAR(100) NOT NULL       
);
INSERT INTO Students (StudentName) VALUES ('Aisha Khan');
INSERT INTO Students (StudentName) VALUES ('Luca Rossi');
INSERT INTO Students (StudentName) VALUES ('Emiko Tanaka');
INSERT INTO Students (StudentName) VALUES ('Mateo Garcia');
INSERT INTO Students (StudentName) VALUES ('Zara Patel');
INSERT INTO Students (StudentName) VALUES ('Ethan Williams');
INSERT INTO Students (StudentName) VALUES ('Leila Muller');

CREATE TABLE Courses (
    CourseID INT PRIMARY KEY IDENTITY(1,1),  
    CourseName NVARCHAR(100) NOT NULL       
);
INSERT INTO Courses (CourseName) VALUES ('Computer Science');
INSERT INTO Courses (CourseName) VALUES ('Mechanical');
INSERT INTO Courses (CourseName) VALUES ('Bio Medical');

CREATE TABLE Subjects (
    SubjectID INT PRIMARY KEY IDENTITY(1,1),  
    SubjectName NVARCHAR(100) NOT NULL        
);
INSERT INTO Subjects (SubjectName) VALUES ('English');
INSERT INTO Subjects (SubjectName) VALUES ('Math');
INSERT INTO Subjects (SubjectName) VALUES ('Programming');
INSERT INTO Subjects (SubjectName) VALUES ('Drawing');
INSERT INTO Subjects (SubjectName) VALUES ('Biology');

CREATE TABLE StudentCourses (
    StudentID INT,                           
    CourseID INT,                           
    PRIMARY KEY (StudentID, CourseID),       
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID) ON DELETE CASCADE,
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID) ON DELETE CASCADE
);
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (1, 1);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (2, 1);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (3, 2);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (4, 2);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (5, 3);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (6, 3);  
INSERT INTO StudentCourses (StudentID, CourseID) VALUES (7, 3);  

CREATE TABLE StudentSubjects (
    StudentID INT,                           
    SubjectID INT,                           
    PRIMARY KEY (StudentID, SubjectID),      
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID) ON DELETE CASCADE,
    FOREIGN KEY (SubjectID) REFERENCES Subjects(SubjectID) ON DELETE CASCADE
);
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (1, 1);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (1, 2);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (2, 2);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (3, 3);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (4, 3);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (4, 2);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (5, 4);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (6, 4);  
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (6, 5); 
INSERT INTO StudentSubjects (StudentID, SubjectID) VALUES (7, 5);  

/*Find all students studying Biology*/
SELECT S.StudentName
FROM Students S
JOIN StudentSubjects SS ON S.StudentID = SS.StudentID
JOIN Subjects Sub ON SS.SubjectID = Sub.SubjectID
WHERE Sub.SubjectName = 'Biology';

/*Find all subjects a student is studying, ex- Luca Rossi*/
SELECT Sub.SubjectName
FROM Students S
JOIN StudentSubjects SS ON S.StudentID = SS.StudentID
JOIN Subjects Sub ON SS.SubjectID = Sub.SubjectID
WHERE S.StudentName = 'Luca Rossi';
