﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Student
{
    public string Name { get; set; }
    public string Course { get; set; } 
    public List<string> Subjects { get; set; }

    public Student(string name, string course, List<string> subjects)
    {
        Name = name;
        Course = course;  
        Subjects = subjects;
    }
}

public class Program
{
    static Dictionary<string, List<Student>> studentsByCourse = new Dictionary<string, List<Student>>();

    public static void Main()
    {
        AddStudent(new Student("Aisha Khan", "Computer Science", new List<string> { "English", "Math" }));
        AddStudent(new Student("Luca Rossi", "Computer Science", new List<string> { "Math" }));
        AddStudent(new Student("Emiko Tanaka", "Mechanical", new List<string> { "Programming" }));
        AddStudent(new Student("Mateo Garcia", "Mechanical", new List<string> { "Programming", "Math" }));
        AddStudent(new Student("Zara Patel", "Bio Medical", new List<string> { "Drawing" }));
        AddStudent(new Student("Ethan Williams", "Bio Medical", new List<string> { "Drawing", "Biology" }));
        AddStudent(new Student("Leila Muller", "Bio Medical", new List<string> { "Biology" }));

        // Problem 1
        Console.WriteLine("Number of students studying English: " + CountStudentsStudyingSubject("English"));
        Console.WriteLine("Number of students studying Programming or Drawing: " + CountStudentsStudyingSubjects(new List<string> { "Programming", "Drawing" }));

        
        AddStudent(new Student("New Student", "Computer Science", new List<string> { "Programming" }));
        Console.WriteLine("Number of students studying Programming after adding a new student: " + CountStudentsStudyingSubject("Programming"));
    

        // Problem 2
        Console.WriteLine("Is Luca Rossi present: " + IsStudentPresent("Luca Rossi"));
        Console.WriteLine("Is Luca Rossi studying Biology: " + IsStudentStudyingSubject("Luca Rossi", "Biology"));

        AddStudent(new Student("New Student", "Computer Science", new List<string> { "Programming" }));
    }

    
    public static int CountStudentsStudyingSubject(string subject)
    {
        return studentsByCourse.Values.SelectMany(students => students).Count(student => student.Subjects.Contains(subject));
    }

    
    public static int CountStudentsStudyingSubjects(List<string> subjects)
    {
        return studentsByCourse.Values.SelectMany(students => students).Count(student => student.Subjects.Any(subject => subjects.Contains(subject)));
    }
    public static void AddStudent(Student student)
    {
        if (!studentsByCourse.ContainsKey(student.Course))  
        {
            studentsByCourse[student.Course] = new List<Student>();
        }
        studentsByCourse[student.Course].Add(student);
    }

    public static bool IsStudentPresent(string studentName)
    {
        return studentsByCourse.Values.SelectMany(students => students).Any(student => student.Name == studentName);
    }

    public static bool IsStudentStudyingSubject(string studentName, string subject)
    {
        return studentsByCourse.Values
            .SelectMany(students => students)
            .Where(student => student.Name == studentName)
            .Any(student => student.Subjects.Contains(subject));
    }
}
