fetch("https://myureli.site/student/add", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      "class": "Comp Science",
      "subject": ["English", "Math", "Programming"]
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.status === "success") {
        console.log("Student added successfully!");
      } else {
        console.log("Failure: " + data.message);
      }
    })
    .catch(error => {
      console.error("Error: Unable to connect to the server.", error);
    });